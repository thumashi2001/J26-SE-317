"""
Clean residual 'nan' string artifacts in expected_relationships column
and log changes to dataset_repair_manifest.csv
"""

import os
import csv
import pandas as pd

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
SYNTH_DIR = os.path.join(SCRIPT_DIR, "synthetic")
REPAIRED_DIR = os.path.join(SYNTH_DIR, "repaired")
MANIFEST_PATH = os.path.join(SCRIPT_DIR, "dataset_repair_manifest.csv")

files_to_check = [
    os.path.join(SYNTH_DIR, "01_FINAL_question_bank.csv"),
    os.path.join(SYNTH_DIR, "02_FINAL_controlled_answers.csv"),
    os.path.join(SYNTH_DIR, "03_FINAL_rubric_criteria.csv"),
    os.path.join(SYNTH_DIR, "question_bank_train.csv"),
    os.path.join(SYNTH_DIR, "question_bank_validation.csv"),
    os.path.join(SYNTH_DIR, "controlled_answers_train.csv"),
    os.path.join(SYNTH_DIR, "controlled_answers_validation.csv"),
    os.path.join(REPAIRED_DIR, "01_FINAL_question_bank_repaired.csv"),
    os.path.join(REPAIRED_DIR, "02_FINAL_controlled_answers_repaired.csv"),
    os.path.join(REPAIRED_DIR, "03_FINAL_rubric_criteria_repaired.csv"),
    os.path.join(REPAIRED_DIR, "question_bank_train_repaired.csv"),
    os.path.join(REPAIRED_DIR, "question_bank_validation_repaired.csv"),
    os.path.join(REPAIRED_DIR, "controlled_answers_train_repaired.csv"),
    os.path.join(REPAIRED_DIR, "controlled_answers_validation_repaired.csv"),
]

existing_manifest = []
if os.path.exists(MANIFEST_PATH):
    with open(MANIFEST_PATH, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        existing_manifest = list(reader)

new_manifest_entries = []

for fpath in files_to_check:
    if not os.path.exists(fpath):
        continue
    df = pd.read_csv(fpath)
    if "expected_relationships" not in df.columns:
        continue
    modified = False
    for idx, row in df.iterrows():
        val = str(row["expected_relationships"])
        if '"nan"' in val:
            new_val = val.replace('"nan", ', "").replace('"nan",', "").replace('"nan"', "")
            new_val = new_val.replace("[, ", "[").replace("[,", "[")
            df.at[idx, "expected_relationships"] = new_val
            modified = True
            if "02_FINAL_controlled_answers" in fpath:
                new_manifest_entries.append({
                    "row_index": str(idx),
                    "question_id": row["question_id"],
                    "answer_id": row.get("answer_id", ""),
                    "split": row.get("split", ""),
                    "module_code": row.get("module_code", ""),
                    "answer_quality": row.get("answer_quality", ""),
                    "defects_identified": "LITERAL_NAN_IN_EXPECTED_RELATIONSHIPS",
                    "original_student_answer": val[:100],
                    "original_expected_mark": str(row.get("expected_mark", "")),
                    "repaired_student_answer": new_val[:100],
                    "repaired_expected_mark": str(row.get("expected_mark", "")),
                    "repaired_criterion_marks": str(row.get("criterion_marks", "")),
                    "repair_action": "PRUNED_LITERAL_NAN_FROM_RELATIONSHIPS_LIST",
                    "repair_rationale": "Removed residual literal nan string artifact from expected_relationships list"
                })
    if modified:
        df.to_csv(fpath, index=False)
        print("Updated:", fpath)

if new_manifest_entries and existing_manifest:
    fieldnames = list(existing_manifest[0].keys())
    with open(MANIFEST_PATH, "a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        for entry in new_manifest_entries:
            writer.writerow(entry)
    print(f"Appended {len(new_manifest_entries)} entries to {MANIFEST_PATH}")
