"""
Repair duplicate variants in PP-SE3010-089 and PP-SE3080-102
Ensures distinct text, meaningful rubric progression, and correct marks.
"""

import os
import csv
import pandas as pd

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
SYNTH_DIR = os.path.join(SCRIPT_DIR, "synthetic")
REPAIRED_DIR = os.path.join(SYNTH_DIR, "repaired")
MANIFEST_PATH = os.path.join(SCRIPT_DIR, "dataset_repair_manifest.csv")

REPLACEMENTS = {
    "PP-SE3010-089": {
        "FULL": (
            "Static testing reviews artifacts and code without runtime execution (e.g. inspections, walkthroughs), while dynamic testing executes code with inputs to observe actual outputs (e.g. unit and integration tests). A decision table maps discount rules: wholesale cash with 50+ items receives 5% discount and free delivery.",
            25.0
        ),
        "MOSTLY_CORRECT": (
            "Static testing analyzes code without execution and dynamic testing runs tests on executing software. A decision table for customer discount conditions is outlined, with minor omission in free delivery threshold coverage.",
            20.0
        ),
        "PARTIAL": (
            "Dynamic testing is explained with an example of executing code against expected outputs, but static testing is only mentioned briefly without examples, and the decision table is incomplete.",
            12.5
        ),
        "MISSING_CONCEPT": (
            "The decision table logic for wholesale and cash discounts is provided, but the response omits the distinction between static and dynamic testing techniques entirely.",
            12.5
        ),
        "MISCONCEPTION": (
            "Static and dynamic testing are treated as identical runtime execution stages, confusing static code analysis with automated dynamic execution.",
            5.0
        ),
        "IRRELEVANT": (
            "The response discusses unrelated material and does not answer the assessment question.",
            0.0
        )
    },
    "PP-SE3080-102": {
        "FULL": (
            "Stakeholders are categorized into the Power/Interest Grid: Product Manager has High Power/High Interest (Manage Closely, Leading); End Users have Low Power/High Interest (Keep Informed, Supportive); Regulatory Authorities have High Power/Low Interest (Keep Satisfied, Neutral); Software Developers have Low Power/Low Interest (Monitor, Supportive).",
            20.0
        ),
        "MOSTLY_CORRECT": (
            "Categorizes the four stakeholders into the Power/Interest grid with appropriate management strategies, but current involvement classifications are partially incomplete for developers.",
            16.0
        ),
        "PARTIAL": (
            "Correctly places the Product Manager and Regulatory Authorities in the grid, but misclassifies End Users and Developers or omits detailed management strategies.",
            10.0
        ),
        "MISSING_CONCEPT": (
            "Discusses general stakeholder management and communication, but omits the formal Power/Interest Grid matrix categorization required by the case study.",
            10.0
        ),
        "MISCONCEPTION": (
            "Places all stakeholders in the High Power/High Interest quadrant, claiming that all project participants require identical daily management and executive oversight.",
            4.0
        ),
        "IRRELEVANT": (
            "The response discusses unrelated material and does not answer the assessment question.",
            0.0
        )
    }
}

manifest_rows = []
if os.path.exists(MANIFEST_PATH):
    with open(MANIFEST_PATH, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        manifest_rows = list(reader)

new_entries = []

files_to_update = [
    os.path.join(SYNTH_DIR, "02_FINAL_controlled_answers.csv"),
    os.path.join(SYNTH_DIR, "controlled_answers_train.csv"),
    os.path.join(REPAIRED_DIR, "02_FINAL_controlled_answers_repaired.csv"),
    os.path.join(REPAIRED_DIR, "controlled_answers_train_repaired.csv"),
]

for fpath in files_to_update:
    if not os.path.exists(fpath):
        continue
    df = pd.read_csv(fpath)
    modified = False
    for idx, row in df.iterrows():
        qid = row["question_id"]
        quality = row.get("answer_quality", "").upper()
        if qid in REPLACEMENTS and quality in REPLACEMENTS[qid]:
            new_text, new_mark = REPLACEMENTS[qid][quality]
            old_text = str(row["student_answer"])
            old_mark = float(row.get("expected_mark", 0.0))
            if old_text != new_text or old_mark != new_mark:
                df.at[idx, "student_answer"] = new_text
                df.at[idx, "expected_mark"] = new_mark
                # Set marks column to question max_marks or expected mark
                modified = True
                if "02_FINAL_controlled_answers" in fpath:
                    new_entries.append({
                        "row_index": str(idx),
                        "question_id": qid,
                        "answer_id": row.get("answer_id", ""),
                        "split": row.get("split", ""),
                        "module_code": row.get("module_code", ""),
                        "answer_quality": quality,
                        "defects_identified": "WITHIN_QUESTION_DUPLICATE_ANSWER_TEXT",
                        "original_student_answer": old_text[:100],
                        "original_expected_mark": str(old_mark),
                        "repaired_student_answer": new_text[:100],
                        "repaired_expected_mark": str(new_mark),
                        "repaired_criterion_marks": str(row.get("criterion_marks", "")),
                        "repair_action": "RECONSTRUCTED_DOMAIN_GROUNDED_ANSWER_VARIANT",
                        "repair_rationale": "Differentiated duplicate within-question variants with domain-grounded criteria content"
                    })
    if modified:
        df.to_csv(fpath, index=False)
        print("Updated:", fpath)

if new_entries and manifest_rows:
    fieldnames = list(manifest_rows[0].keys())
    with open(MANIFEST_PATH, "a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        for entry in new_entries:
            writer.writerow(entry)
    print(f"Appended {len(new_entries)} entries to {MANIFEST_PATH}")
