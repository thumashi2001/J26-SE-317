import pandas as pd

df = pd.read_csv("ai-services/c3/datasets/synthetic/02_FINAL_controlled_answers.csv")
for qid in ["PP-SE3010-089", "PP-SE3080-102"]:
    print("=" * 60)
    print("Question ID:", qid)
    sub = df[df["question_id"] == qid]
    for idx, r in sub.iterrows():
        print(f"[{r['answer_quality']}] mark={r['expected_mark']}: {repr(r['student_answer'])}")
