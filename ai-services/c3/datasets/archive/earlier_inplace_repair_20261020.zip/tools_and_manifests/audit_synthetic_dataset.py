"""
AdaptiveLearnSE Component 3 — Synthetic Dataset Quality & Leakage Audit Script
Validates:
1. Exact row counts across train/val/test and canonical master files.
2. Question ID disjointness across splits.
3. Search for NaN values, empty answers, literal 'nan' strings.
4. Identifies cross-split duplicates and negative control distractors.
5. Score boundary invariants (0 <= mark <= max_marks).
"""

import os
import sys
import json
import hashlib
import pandas as pd
import numpy as np

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
SYNTH_DIR = os.path.join(BASE_DIR, "synthetic")

def run_audit():
    print("=" * 80)
    print("  ADAPTIVE_LEARN_SE C3 DATASET QUALITY AUDIT")
    print("=" * 80)

    train_path = os.path.join(SYNTH_DIR, "controlled_answers_train.csv")
    val_path = os.path.join(SYNTH_DIR, "controlled_answers_validation.csv")
    test_path = os.path.join(SYNTH_DIR, "controlled_answers_test.csv")
    master_path = os.path.join(SYNTH_DIR, "02_FINAL_controlled_answers.csv")
    qb_master = os.path.join(SYNTH_DIR, "01_FINAL_question_bank.csv")

    for p in [train_path, val_path, test_path, master_path, qb_master]:
        if not os.path.exists(p):
            print(f"ERROR: Missing expected file: {p}")
            return

    # Checksums
    def get_sha256(path):
        h = hashlib.sha256()
        with open(path, "rb") as f:
            while chunk := f.read(65536):
                h.update(chunk)
        return h.hexdigest()

    print("\n1. File Inventory & Checksums:")
    for p in [train_path, val_path, test_path, master_path, qb_master]:
        fname = os.path.basename(p)
        print(f"  {fname:<35} | {os.path.getsize(p):>8} bytes | sha256: {get_sha256(p)[:16]}...")

    df_train = pd.read_csv(train_path)
    df_val = pd.read_csv(val_path)
    df_test = pd.read_csv(test_path)
    df_master = pd.read_csv(master_path)
    df_qb = pd.read_csv(qb_master)

    print("\n2. Record Counts:")
    print(f"  Train:      {len(df_train):>5} rows")
    print(f"  Validation: {len(df_val):>5} rows")
    print(f"  Test:       {len(df_test):>5} rows")
    print(f"  Sum splits: {len(df_train) + len(df_val) + len(df_test):>5} rows")
    print(f"  02_FINAL:   {len(df_master):>5} rows")
    print(f"  Question Bank: {len(df_qb):>4} questions")

    # Question ID Disjointness
    q_train = set(df_train["question_id"])
    q_val = set(df_val["question_id"])
    q_test = set(df_test["question_id"])
    print("\n3. Question ID Partitioning:")
    print(f"  Train Unique Qs:      {len(q_train)}")
    print(f"  Validation Unique Qs: {len(q_val)}")
    print(f"  Test Unique Qs:       {len(q_test)}")
    print(f"  Total Unique Qs:      {len(q_train | q_val | q_test)}")
    overlap_tv = q_train & q_val
    overlap_tt = q_train & q_test
    overlap_vt = q_val & q_test
    print(f"  Train-Val Question Overlap:  {len(overlap_tv)}")
    print(f"  Train-Test Question Overlap: {len(overlap_tt)}")
    print(f"  Val-Test Question Overlap:   {len(overlap_vt)}")

    # Literal 'nan' Search
    print("\n4. Literal 'nan' / Missing Values Analysis:")
    splits = [("train", df_train), ("validation", df_val), ("test", df_test)]
    nan_records = []
    for s_name, s_df in splits:
        for idx, row in s_df.iterrows():
            ans_str = str(row["student_answer"])
            if "nan" in ans_str.lower():
                # Check for literal nan substring or word
                if ans_str.strip().lower().startswith("nan ") or " nan " in ans_str.lower():
                    nan_records.append({
                        "split": s_name,
                        "question_id": str(row["question_id"]),
                        "answer_type": str(row.get("quality_type", row.get("answer_type", ""))),
                        "expected_mark": float(row.get("expected_mark", row.get("marks", 0.0))),
                        "max_marks": float(row.get("marks", 10.0)),
                        "student_answer_snippet": ans_str[:90]
                    })

    print(f"  Found {len(nan_records)} records containing literal 'nan' answer text:")
    for r in nan_records:
        print(f"    - Split: {r['split']:<10} | QID: {r['question_id']:<10} | Type: {r['answer_type']:<15} | Mark: {r['expected_mark']:<4}/{r['max_marks']} | Ans: {r['student_answer_snippet']}...")

    # Text Duplicates Across Splits
    print("\n5. Cross-Split Answer Text Overlap (Leakage Check):")
    train_texts = set(df_train["student_answer"].dropna().astype(str).str.strip())
    val_texts = set(df_val["student_answer"].dropna().astype(str).str.strip())
    test_texts = set(df_test["student_answer"].dropna().astype(str).str.strip())

    train_val_dups = train_texts & val_texts
    train_test_dups = train_texts & test_texts
    val_test_dups = val_texts & test_texts
    all_cross_dups = (train_texts & val_texts) | (train_texts & test_texts) | (val_texts & test_texts)
    print(f"  Unique answer texts in Train: {len(train_texts)}")
    print(f"  Unique answer texts in Val:   {len(val_texts)}")
    print(f"  Unique answer texts in Test:  {len(test_texts)}")
    print(f"  Cross-Split Duplicate Strings: {len(all_cross_dups)}")
    print(f"    Train & Val:  {len(train_val_dups)}")
    print(f"    Train & Test: {len(train_test_dups)}")
    print(f"    Val & Test:   {len(val_test_dups)}")

    for i, dup in enumerate(sorted([str(d) for d in all_cross_dups]), 1):
        # Find where this appears
        appearances = []
        for s_name, s_df in splits:
            matches = s_df[s_df["student_answer"].astype(str).str.strip() == dup]
            if len(matches) > 0:
                types = set(matches["quality_type"].dropna()) if "quality_type" in matches.columns else set()
                marks = set(matches["expected_mark"].dropna()) if "expected_mark" in matches.columns else set()
                appearances.append(f"{s_name} (n={len(matches)}, types={types}, marks={marks})")
        print(f"    [{i}] '{dup[:70]}...' -> {', '.join(appearances)}")

    # Score Invariants
    print("\n6. Score Boundary & Invariant Validation:")
    for s_name, s_df in splits:
        mark_col = "expected_mark" if "expected_mark" in s_df.columns else "marks"
        marks = s_df[mark_col].astype(float)
        max_marks = s_df["marks"].astype(float) if "marks" in s_df.columns else 10.0
        negatives = (marks < 0.0).sum()
        exceeds = (marks > max_marks).sum()
        print(f"  {s_name:<10}: min={marks.min():.1f}, max={marks.max():.1f}, negative_count={negatives}, exceeds_max={exceeds}")

    # Output machine-readable audit report
    audit_report = {
        "record_counts": {
            "train": len(df_train),
            "validation": len(df_val),
            "test": len(df_test),
            "total_splits": len(df_train) + len(df_val) + len(df_test),
            "master_02_final": len(df_master),
            "question_bank": len(df_qb)
        },
        "question_partitioning": {
            "train_questions": len(q_train),
            "validation_questions": len(q_val),
            "test_questions": len(q_test),
            "is_disjoint": len(overlap_tv) == 0 and len(overlap_tt) == 0 and len(overlap_vt) == 0
        },
        "nan_defect_count": len(nan_records),
        "nan_records": nan_records,
        "cross_split_duplicates_count": len(all_cross_dups),
        "cross_split_duplicates_breakdown": {
            "train_val": len(train_val_dups),
            "train_test": len(train_test_dups),
            "val_test": len(val_test_dups)
        }
    }

    out_json = os.path.join(SYNTH_DIR, "dataset_quality_audit_results.json")
    with open(out_json, "w", encoding="utf-8") as f:
        json.dump(audit_report, f, indent=2)
    print(f"\nMachine-readable audit report written to: {out_json}")
    return audit_report

if __name__ == "__main__":
    run_audit()
